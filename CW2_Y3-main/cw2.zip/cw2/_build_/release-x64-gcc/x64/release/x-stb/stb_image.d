../_build_/release-x64-gcc/x64/release/x-stb/stb_image.o: \
 stb/src/stb_image.c /usr/include/stdc-predef.h stb/include/stb_image.h \
 /usr/include/stdio.h /usr/include/bits/libc-header-start.h \
 /usr/include/features.h /usr/include/features-time64.h \
 /usr/include/bits/wordsize.h /usr/include/bits/timesize.h \
 /usr/include/sys/cdefs.h /usr/include/bits/long-double.h \
 /usr/include/gnu/stubs.h /usr/include/gnu/stubs-64.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stddef.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stdarg.h \
 /usr/include/bits/types.h /usr/include/bits/typesizes.h \
 /usr/include/bits/time64.h /usr/include/bits/types/__fpos_t.h \
 /usr/include/bits/types/__mbstate_t.h \
 /usr/include/bits/types/__fpos64_t.h /usr/include/bits/types/__FILE.h \
 /usr/include/bits/types/FILE.h /usr/include/bits/types/struct_FILE.h \
 /usr/include/bits/types/cookie_io_functions_t.h \
 /usr/include/bits/stdio_lim.h /usr/include/bits/floatn.h \
 /usr/include/bits/floatn-common.h /usr/include/bits/stdio.h \
 /usr/include/stdlib.h /usr/include/bits/waitflags.h \
 /usr/include/bits/waitstatus.h /usr/include/sys/types.h \
 /usr/include/bits/types/clock_t.h /usr/include/bits/types/clockid_t.h \
 /usr/include/bits/types/time_t.h /usr/include/bits/types/timer_t.h \
 /usr/include/bits/stdint-intn.h /usr/include/endian.h \
 /usr/include/bits/endian.h /usr/include/bits/endianness.h \
 /usr/include/bits/byteswap.h /usr/include/bits/uintn-identity.h \
 /usr/include/sys/select.h /usr/include/bits/select.h \
 /usr/include/bits/types/sigset_t.h /usr/include/bits/types/__sigset_t.h \
 /usr/include/bits/types/struct_timeval.h \
 /usr/include/bits/types/struct_timespec.h \
 /usr/include/bits/pthreadtypes.h /usr/include/bits/thread-shared-types.h \
 /usr/include/bits/pthreadtypes-arch.h \
 /usr/include/bits/atomic_wide_counter.h /usr/include/bits/struct_mutex.h \
 /usr/include/bits/struct_rwlock.h /usr/include/alloca.h \
 /usr/include/bits/stdlib-bsearch.h /usr/include/bits/stdlib-float.h \
 /usr/include/string.h /usr/include/bits/types/locale_t.h \
 /usr/include/bits/types/__locale_t.h /usr/include/strings.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/limits.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/syslimits.h \
 /usr/include/limits.h /usr/include/bits/posix1_lim.h \
 /usr/include/bits/local_lim.h /usr/include/linux/limits.h \
 /usr/include/bits/pthread_stack_min-dynamic.h \
 /usr/include/bits/pthread_stack_min.h /usr/include/bits/posix2_lim.h \
 /usr/include/math.h /usr/include/bits/math-vector.h \
 /usr/include/bits/libm-simd-decl-stubs.h \
 /usr/include/bits/flt-eval-method.h /usr/include/bits/fp-logb.h \
 /usr/include/bits/fp-fast.h \
 /usr/include/bits/mathcalls-helper-functions.h \
 /usr/include/bits/mathcalls.h /usr/include/assert.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/stdint.h \
 /usr/include/stdint.h /usr/include/bits/wchar.h \
 /usr/include/bits/stdint-uintn.h /usr/include/bits/stdint-least.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/emmintrin.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/xmmintrin.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/mmintrin.h \
 /usr/lib/gcc/x86_64-redhat-linux/14/include/mm_malloc.h
/usr/include/stdc-predef.h:
stb/include/stb_image.h:
/usr/include/stdio.h:
/usr/include/bits/libc-header-start.h:
/usr/include/features.h:
/usr/include/features-time64.h:
/usr/include/bits/wordsize.h:
/usr/include/bits/timesize.h:
/usr/include/sys/cdefs.h:
/usr/include/bits/long-double.h:
/usr/include/gnu/stubs.h:
/usr/include/gnu/stubs-64.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/stddef.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/stdarg.h:
/usr/include/bits/types.h:
/usr/include/bits/typesizes.h:
/usr/include/bits/time64.h:
/usr/include/bits/types/__fpos_t.h:
/usr/include/bits/types/__mbstate_t.h:
/usr/include/bits/types/__fpos64_t.h:
/usr/include/bits/types/__FILE.h:
/usr/include/bits/types/FILE.h:
/usr/include/bits/types/struct_FILE.h:
/usr/include/bits/types/cookie_io_functions_t.h:
/usr/include/bits/stdio_lim.h:
/usr/include/bits/floatn.h:
/usr/include/bits/floatn-common.h:
/usr/include/bits/stdio.h:
/usr/include/stdlib.h:
/usr/include/bits/waitflags.h:
/usr/include/bits/waitstatus.h:
/usr/include/sys/types.h:
/usr/include/bits/types/clock_t.h:
/usr/include/bits/types/clockid_t.h:
/usr/include/bits/types/time_t.h:
/usr/include/bits/types/timer_t.h:
/usr/include/bits/stdint-intn.h:
/usr/include/endian.h:
/usr/include/bits/endian.h:
/usr/include/bits/endianness.h:
/usr/include/bits/byteswap.h:
/usr/include/bits/uintn-identity.h:
/usr/include/sys/select.h:
/usr/include/bits/select.h:
/usr/include/bits/types/sigset_t.h:
/usr/include/bits/types/__sigset_t.h:
/usr/include/bits/types/struct_timeval.h:
/usr/include/bits/types/struct_timespec.h:
/usr/include/bits/pthreadtypes.h:
/usr/include/bits/thread-shared-types.h:
/usr/include/bits/pthreadtypes-arch.h:
/usr/include/bits/atomic_wide_counter.h:
/usr/include/bits/struct_mutex.h:
/usr/include/bits/struct_rwlock.h:
/usr/include/alloca.h:
/usr/include/bits/stdlib-bsearch.h:
/usr/include/bits/stdlib-float.h:
/usr/include/string.h:
/usr/include/bits/types/locale_t.h:
/usr/include/bits/types/__locale_t.h:
/usr/include/strings.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/limits.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/syslimits.h:
/usr/include/limits.h:
/usr/include/bits/posix1_lim.h:
/usr/include/bits/local_lim.h:
/usr/include/linux/limits.h:
/usr/include/bits/pthread_stack_min-dynamic.h:
/usr/include/bits/pthread_stack_min.h:
/usr/include/bits/posix2_lim.h:
/usr/include/math.h:
/usr/include/bits/math-vector.h:
/usr/include/bits/libm-simd-decl-stubs.h:
/usr/include/bits/flt-eval-method.h:
/usr/include/bits/fp-logb.h:
/usr/include/bits/fp-fast.h:
/usr/include/bits/mathcalls-helper-functions.h:
/usr/include/bits/mathcalls.h:
/usr/include/assert.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/stdint.h:
/usr/include/stdint.h:
/usr/include/bits/wchar.h:
/usr/include/bits/stdint-uintn.h:
/usr/include/bits/stdint-least.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/emmintrin.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/xmmintrin.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/mmintrin.h:
/usr/lib/gcc/x86_64-redhat-linux/14/include/mm_malloc.h:
